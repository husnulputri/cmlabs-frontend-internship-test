import { createRouter, createWebHistory } from 'vue-router';
import CategoryList from '../views/CategoryList.vue';
import CategoryDetail from '../views/CategoryDetail.vue';
import MealDetail from '../views/MealDetail.vue';

const routes = [
  {
    path: '/',
    name: 'CategoryList',
    component: CategoryList,
  },
  {
    path: '/category/:name',
    name: 'CategoryDetail',
    component: CategoryDetail,
  },
  {
    path: '/meal/:id',
    name: 'MealDetail',
    component: MealDetail,
  },
];

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes,
});

export default router;
