<template>
  <div class="container my-5">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><router-link to="/">Home</router-link></li>
        <li class="breadcrumb-item"><router-link :to="`/category/${meal ? meal.strCategory : ''}`">{{ meal ? meal.strCategory : '' }}</router-link></li>
        <li class="breadcrumb-item active" aria-current="page">{{ meal ? meal.strMeal : '' }}</li>
      </ol>
    </nav>
    <div v-if="meal">
      <h1 class="mb-4">{{ meal.strMeal }}</h1>
      <img :src="meal.strMealThumb" class="img-fluid mb-4" :alt="meal.strMeal">
      <h2>Ingredients</h2>
      <ul>
        <li v-for="(ingredient, index) in ingredients" :key="index">
          {{ ingredient }}
        </li>
      </ul>
      <h2>Instructions</h2>
      <p>{{ meal.strInstructions }}</p>
      <h2>Video Tutorial</h2>
      <div v-if="meal.strYoutube">
        <iframe :src="`https://www.youtube.com/embed/${meal.strYoutube.split('=')[1]}`" width="560" height="315" frameborder="0" allowfullscreen></iframe>
      </div>
    </div>
    <div v-else>
      <p>Loading...</p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MealDetail',
  data() {
    return {
      meal: null,
      ingredients: [],
    };
  },
  mounted() {
    fetch(`https://www.themealdb.com/api/json/v1/1/lookup.php?i=${this.$route.params.id}`)
      .then(response => response.json())
      .then(data => {
        this.meal = data.meals[0];
        if (this.meal) {
          this.ingredients = this.getIngredientsArray();
        }
      })
      .catch(error => {
        console.error('Error fetching meal data:', error);
      });
  },
  methods: {
    getIngredientsArray() {
      const ingredients = [];
      for (let i = 1; i <= 20; i++) {
        if (this.meal[`strIngredient${i}`]) {
          ingredients.push(`${this.meal[`strIngredient${i}`]} - ${this.meal[`strMeasure${i}`]}`);
        } else {
          break;
        }
      }
      return ingredients;
    },
  },
};
</script>

<style scoped>

</style>
