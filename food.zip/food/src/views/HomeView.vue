<!-- src/views/Home.vue -->
<template>
  <div>
    <div class="jumbotron text-center">
      <h1 class="display-4">Welcome to Cooked Meal</h1>
      <p class="lead">Explore a variety of meals and categories.</p>
      <router-link class="btn btn-primary btn-lg" to="/categories">Browse Categories</router-link>
    </div>
    <div class="container">
      <h2 class="my-4">Popular Meals</h2>
      <div class="row">
        <div class="col-md-4" v-for="meal in meals" :key="meal.idMeal">
          <div class="card mb-4">
            <img :src="meal.strMealThumb" class="card-img-top" :alt="meal.strMeal" />
            <div class="card-body">
              <h5 class="card-title">{{ meal.strMeal }}</h5>
              <router-link :to="`/meal/${meal.idMeal}`" class="btn btn-primary">View Details</router-link>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HomePage',
  data() {
    return {
      meals: [],
    };
  },
  created() {
    this.fetchMeals();
  },
  methods: {
    fetchMeals() {
      fetch('https://www.themealdb.com/api/json/v1/1/search.php?f=a') // Fetch meals starting with 'a'
        .then(response => response.json())
        .then(data => {
          this.meals = data.meals;
        });
    },
  },
};
</script>

<style scoped>
.jumbotron {
  background-color: #f8f9fa;
  padding: 2rem 1rem;
}
</style>
