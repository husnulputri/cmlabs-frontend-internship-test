<template>
  <div class="container my-5">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb bg-light">
        <li class="breadcrumb-item"><router-link to="/">Home</router-link></li>
        <li class="breadcrumb-item"><router-link to="/categories">Categories</router-link></li>
        <li class="breadcrumb-item active" aria-current="page">{{ categoryName }}</li>
      </ol>
    </nav>
    <h1 class="mb-4 text-center">{{ categoryName }} Meals</h1>
    <div class="row justify-content-center">
      <div class="col-md-3 mb-4" v-for="meal in meals" :key="meal.idMeal">
        <div class="card shadow-sm h-100 border-0">
          <img :src="meal.strMealThumb" class="card-img-top rounded" :alt="meal.strMeal">
          <div class="card-body text-center">
            <h5 class="card-title mt-3 mb-3">{{ meal.strMeal }}</h5>
            <router-link :to="`/meal/${meal.idMeal}`" class="btn btn-primary btn-sm">View Details</router-link>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'CategoryDetail',
  data() {
    return {
      categoryName: this.$route.params.name,
      meals: [],
    };
  },
  mounted() {
    fetch(`https://www.themealdb.com/api/json/v1/1/filter.php?c=${this.categoryName}`)
      .then(response => response.json())
      .then(data => {
        this.meals = data.meals;
      });
  },
};
</script>

<style scoped>
/* Custom styles for scoped CSS */
.card {
  transition: transform 0.2s ease-in-out;
  border-radius: 15px; /* Rounded corners for cards */
  overflow: hidden; /* Ensure images do not exceed border radius */
  background-color: #f8f9fa; /* Light grey background color */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Soft shadow */
  margin-bottom: 20px; /* Spacing between cards */
}

.card:hover {
  transform: translateY(-5px);
  box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2); /* Larger shadow on hover */
}

.card-title {
  font-size: 1.2rem;
  font-weight: bold; /* Bold title */
  color: #343a40; /* Dark text color */
}

.btn-primary {
  font-size: 0.9rem;
  background-color: #007bff; /* Primary button color */
  border-color: #007bff; /* Button border color */
}

.btn-primary:hover {
  background-color: #0056b3; /* Darker primary color on hover */
  border-color: #0056b3; /* Darker border color on hover */
}

.card-img-top {
  height: 200px; /* Fixed height for image */
  object-fit: cover; /* Ensure image covers the entire card */
  border-top-left-radius: 15px; /* Rounded top-left corner */
  border-top-right-radius: 15px; /* Rounded top-right corner */
}
</style>
